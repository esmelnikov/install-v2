#!/bin/sh
ICAROOT=/opt/Citrix/ICAClient
export ICAROOT
LD_LIBRARY_PATH=/opt/Citrix/ICAClient/lib
export LD_LIBRARY_PATH
echo '*********before'+$1 >>~/.ICAClient/iuspt.log
grep "SSLProxy" $1>>~/.ICAClient/iuspt.log
sed -i 's/sg.ctx.codm.gazprom.ru/127.0.0.1/; s/sg-pdn.ctx.codm.gazprom.ru\:443/127.0.0.1\:444/' $1
echo '****** After'+$1 >>~/.ICAClient/iuspt.log
grep "SSLProxy" $1>>~/.ICAClient/iuspt.log
$ICAROOT/wfica -file $1
